<?php
file_put_contents(__DIR__.'/prueba.txt', "¡PHP ejecutado con éxito!\n");
echo "Prueba ejecutada";