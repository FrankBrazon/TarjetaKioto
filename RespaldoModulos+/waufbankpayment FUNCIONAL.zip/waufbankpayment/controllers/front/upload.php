<?php

class WaufBankPaymentUploadModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        ob_clean(); // Limpia cualquier salida previa (espacios, errores, BOM)
        header('Content-Type: application/json');

        header('Content-Type: application/json'); // 👈 NECESARIO para que JS lo interprete como JSON

        if (
            isset($_FILES['soporte_pago']) &&
            $_FILES['soporte_pago']['error'] === UPLOAD_ERR_OK
        ) {
            $uploadDir = _PS_IMG_DIR_ . 'comprobantes/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $filename = 'comprobante_' . time() . '.jpg';
            $destination = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['soporte_pago']['tmp_name'], $destination)) {
                echo json_encode(['success' => '✅ Archivo subido con éxito']);
                exit;
            } else {
                echo json_encode(['error' => 'Error al mover el archivo']);
                exit;
            }
        } else {
            echo json_encode(['error' => 'No se recibió archivo']);
            exit;
        }
    }
}

