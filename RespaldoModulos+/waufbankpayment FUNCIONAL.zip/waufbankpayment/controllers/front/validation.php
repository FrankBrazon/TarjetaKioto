<?php

class WaufBankPaymentValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        $cart = $this->context->cart;

        if (!Validate::isLoadedObject($cart) || !$cart->id) {
            die('❌ Error: Carrito inválido.');
        }

        $customer = new Customer((int)$cart->id_customer);
        $orderTotal = $cart->getOrderTotal(true, Cart::BOTH);

        // ✅ 1. Crear el pedido
        $this->module->validateOrder(
            (int)$cart->id,
            Configuration::get('PS_OS_BANKWIRE'), // o PS_OS_PENDING si prefieres
            $orderTotal,
            $this->module->displayName,
            null,
            [],
            (int)$cart->id_currency,
            false,
            $customer->secure_key
        );

        $order = new Order($this->module->currentOrder);

        // ✅ 2. Subir el archivo si vino en la request
        if (isset($_FILES['soporte_pago']) && $_FILES['soporte_pago']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = _PS_IMG_DIR_ . 'comprobantes/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $destination = $uploadDir . $order->id . '.jpg';
            move_uploaded_file($_FILES['soporte_pago']['tmp_name'], $destination);
        }

        // ✅ 3. Redirigir a la página de confirmación del pedido
        Tools::redirect('index.php?controller=order-confirmation&id_cart=' . (int)$cart->id .
            '&id_module=' . (int)$this->module->id .
            '&id_order=' . (int)$this->module->currentOrder .
            '&key=' . $customer->secure_key);
    }

}
