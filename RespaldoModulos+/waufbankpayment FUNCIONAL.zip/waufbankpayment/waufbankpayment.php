<?php
if (!defined('_PS_VERSION_')) exit;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class WaufBankPayment extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'waufbankpayment';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.3';
        $this->author = 'Frank Brazon R';
        $this->need_instance = 0;

        parent::__construct();

        $this->displayName = $this->l('Pago por Transferencia o Pago Móvil');
        $this->description = $this->l('Permite pagar mediante transferencia o pago móvil y subir soporte.');
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
    }

    public function install()
    {
        $folder = _PS_IMG_DIR_ . 'comprobantes/';
        if (!file_exists($folder)) {
            @mkdir($folder, 0755, true);
        }

        return parent::install()
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn')
            && $this->registerHook('displayAdminOrderContentOrder');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        $newOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $newOption->setCallToActionText($this->l('Transferencia o Pago Móvil'))
                ->setModuleName($this->name)
                ->setForm($this->context->smarty->fetch('module:' . $this->name . '/views/templates/hook/payment_options.tpl'));

        return [$newOption];
    }

    

    public function hookPaymentReturn($params)
    {
        return $this->context->smarty->fetch('module:' . $this->name . '/views/templates/hook/payment_execution.tpl');
    }

    public function hookDisplayAdminOrderContentOrder($params)
    {
        $id_order = (int)$params['order']->id;
        $relative_path = 'img/comprobantes/' . $id_order . '.jpg';
        $absolute_path = _PS_ROOT_DIR_ . '/' . $relative_path;

        if (file_exists($absolute_path)) {
            $url = _PS_BASE_URL_ . __PS_BASE_URI__ . $relative_path;
            return '<strong>Soporte de pago:</strong><br><img src="' . $url . '" style="max-width:300px">';
        }
        return '';
    }

    
}
